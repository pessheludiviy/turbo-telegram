from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):

    is_cafe=models.BooleanField("Кафе", default = False)
    is_cinema=models.BooleanField("Кинотеатр", default=False)
    is_outside=models.BooleanField("Отдых на свежем воздухе", default = False)
    is_TC=models.BooleanField("Торговые центры", default=False)

