var a = 0;
var b = 0;
var c = 0;
var d = 0;

function fnc1(checkbox) {
    a=1;
  }

function fnc2(checkbox) {
    b=1;
}

function fnc3(checkbox) {
    c=1;
}

function fnc4(checkbox) {
    d=1;
}

