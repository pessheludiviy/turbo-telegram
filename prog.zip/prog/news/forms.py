from .models import Articles
from django.forms import ModelForm, TextInput, DateTimeInput, Textarea

class ArticlesForm(ModelForm):
    class Meta:
        model = Articles
        fields = ['title', 'anons', 'contents', 'date']

        widgets = {
            "title": TextInput(attrs={
                'class': 'form-control',
                'placeholder': '[Номер тикета] Название'
            }),
            "anons": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Краткое содержание/оценка (0-10/10)'
            }),
            "date": DateTimeInput(attrs={
                'class': 'form-control',
                'placeholder': 'Дата/Время публикации'
            }),
            "contents": Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Содержание отзыва'
            })
        }