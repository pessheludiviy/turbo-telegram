from django.shortcuts import render


def index(request):
    data = {
        'title': 'Главная страница',
        'values': ['Some', 'hello', '123']
    }
    return render(request, 'main/projj.html', data)

def func(request):
    return render(request, 'func/func-home.html')
