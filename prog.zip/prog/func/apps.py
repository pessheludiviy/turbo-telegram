from django.apps import AppConfig


class FuncConfig(AppConfig):
    name = 'func'
